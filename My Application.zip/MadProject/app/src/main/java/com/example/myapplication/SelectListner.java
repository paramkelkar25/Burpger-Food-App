package com.example.myapplication;

public interface SelectListner {
    void onItemClicked(foodModel foodmodel);
}
