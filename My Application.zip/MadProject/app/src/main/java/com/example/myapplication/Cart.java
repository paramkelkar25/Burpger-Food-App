package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;


import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Iterator;

public class Cart extends AppCompatActivity {

    RecyclerView recyclerView;

    ArrayList<priceHolder> item;
    Button placeOrder, btoHome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cart);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        recyclerView = findViewById(R.id.BillView);
        placeOrder = findViewById(R.id.placeOrder);
        btoHome = findViewById(R.id.BackToHome);


        Intent intent = getIntent();
        Bundle args = intent.getBundleExtra("Bundle");
        assert args != null;
        ArrayList<priceHolder> object = (ArrayList<priceHolder>) args.getSerializable("order");

        Iterator<priceHolder> iterator = object.iterator();


        item = new ArrayList<>();

        while (iterator.hasNext()) {
            item.add(iterator.next());
            Log.d("item", item.get(0).getName());
        }

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new billViewAdapter(getApplicationContext(), item));

        placeOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Cart.this, ThankYou.class);
                startActivity(intent);
                finish();
            }
        });

        btoHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Cart.this, HomePage.class);
                startActivity(intent);
                finish();
            }
        });

    }
}